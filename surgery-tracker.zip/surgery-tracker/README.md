# 🔪 30-Day Surgery Study Tracker · MBBS

> *"The secret of getting ahead is getting started."* — Mark Twain

A focused, high-yield 30-day study system for Surgery university exams — built around **3 hours/day**, **Marrow**, and **Bailey & Love**.

---

## 📌 At a Glance

| Item | Detail |
|------|--------|
| 📅 Duration | 30 Days |
| ⏱️ Daily Commitment | 3 Hours |
| 📚 Primary Resource | Marrow (Video + Notes) |
| 📖 Reference | Bailey & Love's Short Practice of Surgery |
| 🎯 Goal | High-yield exam preparation, not full textbook coverage |

---

## 🗂️ Repository Structure

```
surgery-tracker/
│
├── README.md                  ← You are here
│
├── tracker/
│   ├── day01.md – day30.md   ← Daily study checklists
│   └── TEMPLATE.md            ← Blank template for custom days
│
├── progress/
│   ├── weekly-dashboard.md    ← Weekly overview table
│   ├── habit-streak.md        ← Streak tracker
│   └── revision-priority.md   ← High-priority revision list
│
├── notes/
│   └── README.md              ← Notes folder guide
│
└── docs/
    ├── study-strategy.md      ← Full strategy breakdown
    └── github-projects.md     ← GitHub Projects board setup guide
```

---

## ⏱️ Daily 3-Hour Study Split

| Block | Time | Activity |
|-------|------|----------|
| 🎬 Block 1 | 60 min | Marrow lecture(s) + notes |
| 📖 Block 2 | 60 min | Bailey & Love — relevant chapter |
| 🔁 Block 3 | 40 min | Revision of previous day's topics |
| ❓ Block 4 | 20 min | PYQs / MCQs on today's topic |

> **Tip:** If short on time, never skip Block 1 and Block 4. Marrow + PYQs = core exam prep.

---

## 📅 30-Day Phase Plan

### 🟦 Phase 1 — Foundations (Day 1–8)
Core surgical principles and high-frequency exam topics.

| Days | Topics |
|------|--------|
| 1–2 | Wounds, Wound Healing, Surgical Infections |
| 3–4 | Shock, Fluid & Electrolytes, Blood Transfusion |
| 5–6 | Pre-op & Post-op Management, Anaesthesia Basics |
| 7–8 | Burns, Trauma, ATLS Principles |

### 🟨 Phase 2 — Systems (Day 9–22)
Organ-system surgery, most commonly tested in theory and viva.

| Days | Topics |
|------|--------|
| 9–10 | Breast — Benign & Malignant |
| 11–12 | Thyroid & Parathyroid |
| 13–14 | GI Tract — Esophagus, Stomach, Peptic Ulcer |
| 15–16 | Small Intestine, Appendix, Meckel's |
| 17–18 | Colorectal, Anal Canal, Hemorrhoids |
| 19–20 | Liver, Biliary System, Pancreas |
| 21–22 | Hernias (all types) |

### 🟥 Phase 3 — Consolidation (Day 23–27)
Remaining topics + high-yield areas.

| Days | Topics |
|------|--------|
| 23 | Urology — Kidney, Bladder, Prostate |
| 24 | Vascular Surgery, Varicose Veins |
| 25 | Head & Neck Surgery, Salivary Glands |
| 26 | Orthopedics Overview (if in syllabus) |
| 27 | Skin, Soft Tissue Tumors, Lymph Nodes |

### 🟩 Phase 4 — Revision & Mock (Day 28–30)
Final push — no new topics.

| Day | Activity |
|-----|----------|
| 28 | Full revision of Phase 1 topics + PYQs |
| 29 | Full revision of Phase 2 topics + PYQs |
| 30 | Full revision of Phase 3 + Mock test simulation |

---

## 🚀 How to Use This Tracker

### Step 1 — Set Up
1. Fork or clone this repository to your GitHub account
2. Open `progress/weekly-dashboard.md` to see the full overview
3. Start with `tracker/day01.md` each morning

### Step 2 — Daily Routine
1. Open the day's tracker file (e.g., `tracker/day05.md`)
2. Check off each task as you complete it using `[x]`
3. Fill in the **Notes** section with key points, mnemonics, or doubts
4. Update your confidence score in `progress/weekly-dashboard.md`

### Step 3 — Track Streaks
- Update `progress/habit-streak.md` every day you study
- Mark ✅ for completed days, ❌ for missed, ⚠️ for partial

### Step 4 — Weekly Review
- Every Sunday, review `progress/weekly-dashboard.md`
- Add topics with low confidence scores to `progress/revision-priority.md`

---

## 📊 Progress Tracking Guide

**Confidence Scale (1–5):**

| Score | Meaning |
|-------|---------|
| 1 | Barely covered, need full re-study |
| 2 | Read but not retained |
| 3 | Moderate — can recall with effort |
| 4 | Good — can answer most questions |
| 5 | Confident — ready for exam |

> Any topic scoring **1 or 2** should be added to `revision-priority.md` immediately.

---

## 💡 Study Tips

- **Marrow first, always.** It's the fastest path to exam-relevant knowledge.
- **Bailey for depth.** Use it to understand *why*, not just *what*.
- **PYQs are non-negotiable.** Surgery exams are predictable — patterns repeat.
- **Teach out loud.** After each topic, explain it to yourself as if presenting to a professor.
- **Don't restart days.** A partial day is infinitely better than a skipped day.

---

## 🔥 Motivation

Surgery is demanding. The subject is vast. But 30 days of consistent, focused effort — even just 3 hours a day — compounds into something remarkable.

You are not trying to read every page of Bailey & Love.
You are building a **mental model** of Surgery that holds up under exam pressure.

**One topic at a time. One day at a time. That's all it takes.**

---

## 📎 Quick Links

- [📋 Weekly Dashboard](progress/weekly-dashboard.md)
- [🔥 Habit Streak](progress/habit-streak.md)
- [⚠️ Revision Priority List](progress/revision-priority.md)
- [📖 Study Strategy (Full)](docs/study-strategy.md)
- [🗂️ GitHub Projects Setup](docs/github-projects.md)
- [📝 Day Tracker Template](tracker/TEMPLATE.md)

---

<div align="center">

**Built for MBBS Surgery · Powered by consistency**

*Start Day 1 → [tracker/day01.md](tracker/day01.md)*

</div>
