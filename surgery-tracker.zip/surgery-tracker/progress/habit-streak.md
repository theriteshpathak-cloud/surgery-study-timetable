# 🔥 Habit Streak Tracker

> Mark every day you study. Consistency beats intensity.
>
> ✅ = Full session (3 hrs) · ⚠️ = Partial session (<3 hrs) · ❌ = Missed · 🌟 = Exceptional (bonus revision)

---

## How to Use

1. At the end of each day, find your day number below
2. Replace the `⬜` with the appropriate symbol
3. Calculate your streak in the summary

---

## 📅 30-Day Log

| Day | Date | Status | Hours Studied | Notes |
|-----|------|:------:|:-------------:|-------|
| Day 01 | `____-__-__` | ⬜ | | |
| Day 02 | `____-__-__` | ⬜ | | |
| Day 03 | `____-__-__` | ⬜ | | |
| Day 04 | `____-__-__` | ⬜ | | |
| Day 05 | `____-__-__` | ⬜ | | |
| Day 06 | `____-__-__` | ⬜ | | |
| Day 07 | `____-__-__` | ⬜ | | |
| Day 08 | `____-__-__` | ⬜ | | |
| Day 09 | `____-__-__` | ⬜ | | |
| Day 10 | `____-__-__` | ⬜ | | |
| Day 11 | `____-__-__` | ⬜ | | |
| Day 12 | `____-__-__` | ⬜ | | |
| Day 13 | `____-__-__` | ⬜ | | |
| Day 14 | `____-__-__` | ⬜ | | |
| Day 15 | `____-__-__` | ⬜ | | |
| Day 16 | `____-__-__` | ⬜ | | |
| Day 17 | `____-__-__` | ⬜ | | |
| Day 18 | `____-__-__` | ⬜ | | |
| Day 19 | `____-__-__` | ⬜ | | |
| Day 20 | `____-__-__` | ⬜ | | |
| Day 21 | `____-__-__` | ⬜ | | |
| Day 22 | `____-__-__` | ⬜ | | |
| Day 23 | `____-__-__` | ⬜ | | |
| Day 24 | `____-__-__` | ⬜ | | |
| Day 25 | `____-__-__` | ⬜ | | |
| Day 26 | `____-__-__` | ⬜ | | |
| Day 27 | `____-__-__` | ⬜ | | |
| Day 28 | `____-__-__` | ⬜ | | |
| Day 29 | `____-__-__` | ⬜ | | |
| Day 30 | `____-__-__` | ⬜ | | |

---

## 📊 Streak Summary

| Metric | Value |
|--------|-------|
| 🔥 Current Streak | `__ days` |
| 🏆 Longest Streak | `__ days` |
| ✅ Full Sessions | `__ / 30` |
| ⚠️ Partial Sessions | `__ / 30` |
| ❌ Missed Days | `__ / 30` |
| ⏱️ Total Hours Studied | `__ hrs` |

---

## 🗓️ Visual Streak Map

> Fill in as you go — use ✅ ⚠️ ❌ 🌟

```
Week 1:  [ ][ ][ ][ ][ ][ ][ ]
Week 2:  [ ][ ][ ][ ][ ][ ][ ]
Week 3:  [ ][ ][ ][ ][ ][ ][ ]
Week 4:  [ ][ ][ ][ ][ ][ ][ ][ ][ ]
```

---

## 💬 Streak Rules

- **Never miss twice in a row.** One missed day is a stumble. Two is a habit.
- **Partial > Zero.** Even 45 minutes counts as ⚠️ — log it, don't lose it.
- **The goal is 25+ full days.** Life happens. 25/30 is excellent. 30/30 is extraordinary.

---

*[📊 Dashboard](weekly-dashboard.md) · [⚠️ Revision Priority](revision-priority.md) · [🏠 Home](../README.md)*
