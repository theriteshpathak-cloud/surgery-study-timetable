# 📊 Weekly Progress Dashboard

> Track your daily progress at a glance. Update after every study session.
>
> **Confidence Scale:** 1 = Weak · 2 = Shaky · 3 = Moderate · 4 = Good · 5 = Exam-Ready

---

## 🟦 Week 1 — Phase 1: Foundations (Day 1–7)

| Day | Topic | Completed | Confidence (1–5) | Remarks |
|-----|-------|:---------:|:----------------:|---------|
| [Day 01](../tracker/day01.md) | Wounds & Wound Healing | ⬜ | — | |
| [Day 02](../tracker/day02.md) | Surgical Infections | ⬜ | — | |
| [Day 03](../tracker/day03.md) | Shock | ⬜ | — | |
| [Day 04](../tracker/day04.md) | Fluids, Electrolytes & Blood Transfusion | ⬜ | — | |
| [Day 05](../tracker/day05.md) | Pre-operative Assessment & Consent | ⬜ | — | |
| [Day 06](../tracker/day06.md) | Post-operative Care & Complications | ⬜ | — | |
| [Day 07](../tracker/day07.md) | Burns | ⬜ | — | |

**Week 1 Summary**
- Topics completed: `__ / 7`
- Average confidence: `__`
- Topics needing revision: 

---

## 🟦 Week 2 — Phase 1 End + Phase 2 Begin (Day 8–14)

| Day | Topic | Completed | Confidence (1–5) | Remarks |
|-----|-------|:---------:|:----------------:|---------|
| [Day 08](../tracker/day08.md) | Trauma & ATLS Principles | ⬜ | — | |
| [Day 09](../tracker/day09.md) | Breast — Benign Conditions | ⬜ | — | |
| [Day 10](../tracker/day10.md) | Breast — Malignant Conditions | ⬜ | — | |
| [Day 11](../tracker/day11.md) | Thyroid — Benign & Investigations | ⬜ | — | |
| [Day 12](../tracker/day12.md) | Thyroid Cancer & Parathyroid | ⬜ | — | |
| [Day 13](../tracker/day13.md) | Oesophagus & GORD | ⬜ | — | |
| [Day 14](../tracker/day14.md) | Stomach & Peptic Ulcer Disease | ⬜ | — | |

**Week 2 Summary**
- Topics completed: `__ / 7`
- Average confidence: `__`
- Topics needing revision: 

---

## 🟨 Week 3 — Phase 2: Systems Continued (Day 15–21)

| Day | Topic | Completed | Confidence (1–5) | Remarks |
|-----|-------|:---------:|:----------------:|---------|
| [Day 15](../tracker/day15.md) | Small Intestine & Appendix | ⬜ | — | |
| [Day 16](../tracker/day16.md) | Large Intestine — Benign | ⬜ | — | |
| [Day 17](../tracker/day17.md) | Colorectal Cancer | ⬜ | — | |
| [Day 18](../tracker/day18.md) | Anal Canal & Perianal Conditions | ⬜ | — | |
| [Day 19](../tracker/day19.md) | Liver & Portal Hypertension | ⬜ | — | |
| [Day 20](../tracker/day20.md) | Biliary System | ⬜ | — | |
| [Day 21](../tracker/day21.md) | Pancreas | ⬜ | — | |

**Week 3 Summary**
- Topics completed: `__ / 7`
- Average confidence: `__`
- Topics needing revision: 

---

## 🟥 Week 4 — Phase 2 End + Phase 3 + Revision (Day 22–30)

| Day | Topic | Completed | Confidence (1–5) | Remarks |
|-----|-------|:---------:|:----------------:|---------|
| [Day 22](../tracker/day22.md) | Hernias | ⬜ | — | |
| [Day 23](../tracker/day23.md) | Urology — Kidney & Upper Tract | ⬜ | — | |
| [Day 24](../tracker/day24.md) | Urology — Bladder, Prostate & Testis | ⬜ | — | |
| [Day 25](../tracker/day25.md) | Vascular Surgery | ⬜ | — | |
| [Day 26](../tracker/day26.md) | Head & Neck Surgery | ⬜ | — | |
| [Day 27](../tracker/day27.md) | Skin, Soft Tissue & Lymph Nodes | ⬜ | — | |
| [Day 28](../tracker/day28.md) | Phase 1 Revision — Foundations | ⬜ | — | |
| [Day 29](../tracker/day29.md) | Phase 2 Revision — Systems | ⬜ | — | |
| [Day 30](../tracker/day30.md) | Phase 3 Revision + Mock Simulation | ⬜ | — | |

**Week 4 Summary**
- Topics completed: `__ / 9`
- Average confidence: `__`
- Topics needing revision: 

---

## 🏆 Overall Progress

| Metric | Value |
|--------|-------|
| Total days completed | `__ / 30` |
| Overall completion % | `__%` |
| Topics with confidence ≥ 4 | `__ / 30` |
| Topics on revision list | `__` |
| Current streak | `__ days` |

---

## 📈 Confidence Overview (Fill after each week)

| Topic | Week 1 | Week 2 | Week 3 | Week 4 |
|-------|:------:|:------:|:------:|:------:|
| Wounds & Wound Healing | — | — | — | — |
| Surgical Infections | — | — | — | — |
| Shock | — | — | — | — |
| Fluids & Electrolytes | — | — | — | — |
| Pre/Post-op Care | — | — | — | — |
| Burns | — | — | — | — |
| Trauma/ATLS | — | — | — | — |
| Breast | — | — | — | — |
| Thyroid/Parathyroid | — | — | — | — |
| Upper GI | — | — | — | — |
| Lower GI | — | — | — | — |
| Colorectal Ca | — | — | — | — |
| Anorectal | — | — | — | — |
| HPB (Liver/Biliary/Pancreas) | — | — | — | — |
| Hernias | — | — | — | — |
| Urology | — | — | — | — |
| Vascular | — | — | — | — |
| Head & Neck | — | — | — | — |
| Skin & Soft Tissue | — | — | — | — |

---

*[🔥 Streak Tracker](habit-streak.md) · [⚠️ Revision Priority](revision-priority.md) · [🏠 Home](../README.md)*
