# ⚠️ Revision Priority List

> Add any topic here that scores **≤ 2** on the confidence scale, or any topic that keeps tripping you up.
> Review this list during Phase 4 (Day 28–30) and before the exam.

---

## 🔴 High Priority — Must Revise Before Exam

> Confidence score 1–2. Do not enter the exam hall without revisiting these.

| # | Topic | Sub-topic / Weak Area | Confidence | Added On | Revised? |
|---|-------|-----------------------|:----------:|----------|:--------:|
| 1 | | | | | ⬜ |
| 2 | | | | | ⬜ |
| 3 | | | | | ⬜ |
| 4 | | | | | ⬜ |
| 5 | | | | | ⬜ |

---

## 🟡 Medium Priority — Needs Another Pass

> Confidence score 3. Good base but gaps remain.

| # | Topic | Sub-topic / Weak Area | Confidence | Added On | Revised? |
|---|-------|-----------------------|:----------:|----------|:--------:|
| 1 | | | | | ⬜ |
| 2 | | | | | ⬜ |
| 3 | | | | | ⬜ |
| 4 | | | | | ⬜ |
| 5 | | | | | ⬜ |

---

## 🔁 Frequently Confused Topics

> Pairs or groups of topics that you tend to mix up — compare them here.

| Confused Pair | Key Differentiator |
|---------------|-------------------|
| Keloid vs Hypertrophic Scar | Keloid extends beyond wound margins; recurs after excision |
| Direct vs Indirect Inguinal Hernia | Direct through Hesselbach's triangle; Indirect through deep ring |
| Amoebic vs Pyogenic Liver Abscess | Amoebic: single, right lobe, young male; Pyogenic: multiple, elderly, biliary source |
| Ulcerative Colitis vs Crohn's | UC: continuous, rectum → proximal, mucosal; Crohn's: skip lesions, transmural, any GI |
| Courvoisier's Law | Palpable GB + jaundice = NOT gallstones (usually periampullary Ca) |
| | |
| | |
| | |

---

## 📌 High-Yield Topics for This Exam

> Topics that appear in almost every Surgery university paper — ensure confidence ≥ 4.

- [ ] Wound healing (types, phases, factors)
- [ ] Shock classification and management
- [ ] Burns — Rule of Nines, Parkland formula
- [ ] Acute appendicitis — all aspects
- [ ] Intestinal obstruction — causes, management
- [ ] Breast cancer staging and treatment
- [ ] Thyroid swelling approach (clinical + investigations)
- [ ] Hernia — types, anatomy, surgical repair
- [ ] Obstructive jaundice — causes, investigations, management
- [ ] Colorectal cancer — Duke's staging, surgical options
- [ ] Portal hypertension — causes, varices management
- [ ] Haemorrhoids — grades, treatment modalities
- [ ] Peptic ulcer complications
- [ ] BPH vs Ca prostate
- [ ] Varicose veins — CEAP classification, treatment

---

## 🗒️ Mnemonics Bank

> Collect all mnemonics here as you study.

| Topic | Mnemonic / Memory Aid |
|-------|-----------------------|
| Post-op fever causes | **5 W's** — Wind (Day 1–2), Water (Day 3–5), Wound (Day 5–7), Walking/DVT (Day 5+), Wonder drugs |
| Ranson's criteria (pancreatitis) | **GA LAW** (admission) + **C HOBBS** (48 hrs) |
| Duke's staging | A = confined to bowel wall; B = through wall; C = nodes; D = distant mets |
| Thyroid Ca types | **Papillary** = most common; **Follicular** = haematogenous spread; **Medullary** = calcitonin; **Anaplastic** = worst |
| Fontaine classification (PAD) | I = asymptomatic; II = claudication; III = rest pain; IV = ulcer/gangrene |
| | |
| | |

---

*[📊 Dashboard](weekly-dashboard.md) · [🔥 Streak](habit-streak.md) · [🏠 Home](../README.md)*
